using System;
using UnityEditor.Callbacks;
using UnityEngine;
using UnityEngine.InputSystem;

public class BallScriptPink : MonoBehaviour        // this is a script named "Ball_Script"
{                                               // BEGIN BALL SCRIPT

// ***************  HERE WE ARE GOING TO DECLARE SOME VARIABLES  ************************
	public GameObject pinkBall;                // public reference to our Pink Ball Object
	public Rigidbody2D my_rb;                  // here I am declaring a public Rigidbody2D and I am naming it "my_rb"
	public int jumpForce;                       // here I am declaring a public integer (a whole number, aka a number that CAN'T have a decimal point)       
	public float moveSpeed;                     // here I am declaring a public float (number than CAN have a decimal)
	public KeyCode leftMoveKey;                 // here I am declaring a public KeyCode 
	private KeyCode rightMoveKey;               // here I am declaring a private KeyCode. This means that I CAN'T edit or assign this 
												// in the inspector window. Because of this, I will have to tell the computer what 
												// 'rightMoveKey' is somewhere else. In this case, I do that on line 23

	// ***************  HERE WE ARE GOING TO START OUR CODE  ************************
	void Start()                                                // START FUNCTION (Start is called once before the first execution of Update)
	{                                                           // BEGIN START FUNCTION
		Debug.Log("BallScript Start Function Was Called");      // This prints the string "BallScript Start Function Was Called" to the console
		rightMoveKey = KeyCode.D;                     			// here we are initializing the variable "rightMoveKey" which we initialized 
																// before the Start function on line 15. Initializing this variable
																// means telling the computer that when we say "rightMoveKey" we mean 
																// the Right Arrow Key.
		my_rb = GetComponent<Rigidbody2D>();                    // Here are telling the computer that "my_rb" is the Rigidbody2D 
	}                                                           // END START FUNCTION


	void FixedUpdate()                                                      // FIXED UPDATE FUNCTION which runs every fixed frame 
	{                                                                       // BEGIN 'JUMP' 'if' statement
		if (Input.GetKey(KeyCode.W))                                        // IF there is computer input, from a keyboard, and that key is the W key
		{                                                                   // THEN...
			my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);    // take 'my_rb' (the Rigidbody2D we declared on 
																			// line 27 and named 'my_rb') and -add force- to my_rb
		}
		// LET'S MOVE LEFT!
		if (Input.GetKey(leftMoveKey))                                      // IF we pressed the 'leftMoveKey' (which we 
																			// define in the inspector window and NOT in the Start Function)
		{                                                                   // THEN...
			my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);  // we get the rigidbody and add a vector2 impulse force moving it to 
																			// the left and then multiply that by the "moveSpeed" variable we are
																			// setting in the inspector window and declared on line 13
		}                                                                   // END MOVE LEFT IF STATEMENT

		// LET'S MOVE RIGHT!
		if (Input.GetKey(rightMoveKey))                                     // IF we pressed the 'rightMoveKey' (which we are initializing 
																			// on line 23 of the Start function, and NOT in the Inspector)
		{                                                                   // THEN
			my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse); // add a force to our rigidbody that moves it to the right
		}                                                                   // END 'MOVE RIGHT' 'if' statement 
		}                                                                   // END UPDATE FUNCTION
} 																			// END "BallScriptPink" SCRIPT



// ***************  THIS IS THE END OF OUR CODE  ************************


// ***************  KEY TERMS  ************************
//  variable
//  inspector
//  declaring
//  initializing
//  public
//  private
//  debug.log
//  string
//  float
//  integer (aka 'int')
//  GameObject
//  Input
//  KeyCode
//  string
//  Rigidbody2D
//  Vector2
//  Vector3
//  ||
//  &&
//  ++
//  *
//  ==
//  =
// !=






// ***************  IGNORE EVERYTHING BELOW THIS LINE!  ************************
