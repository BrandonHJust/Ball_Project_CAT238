using UnityEngine;

public class GreenBallScript : MonoBehaviour
{

    public float moveSpeed;

    public float jumpForce;
    
    public GameObject greenBall;

    public Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Oh, Hello there. This is the GreenBallScript's Start ;P ");
    }

    // Update is called once per frame
    void Update()
    {
        

        if (Input.GetKeyDown(KeyCode.RightArrow)) {

            Debug.Log("Right Arrow Key Pressed");
            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
       
        if (Input.GetKeyDown(KeyCode.LeftArrow)) {

            Debug.Log("Left Arrow Key Pressed");
            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.Space)) {

            Debug.Log("Up Arrow Key Pressed");
            GreenBallJump();
        }
        
    }
    void GreenBallJump()
    {
        Debug.Log("My First Custom Function is running!!!");
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
